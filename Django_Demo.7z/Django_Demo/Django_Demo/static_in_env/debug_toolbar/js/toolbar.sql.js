(function () {
    djdt.applyStyle('background-color');
    djdt.applyStyle('left');
    djdt.applyStyle('width');
})();
