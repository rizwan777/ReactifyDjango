import React from 'react';
import { Route } from 'react-router-dom'
import MainProducts from './Components/front_product_view'
import DetailProductView from './Components/detail_products_view'


const BaseRouter=()=>{
    return ( 
        <div>
            <Route exact path="/chuangze.cn/" component={MainProducts}/>
            <Route exact path='/chuangze.cn/:id/' component={DetailProductView}/>
        </div>
     );
}
 
export default BaseRouter;
 


// export default BaseRouter;
