import React, { Component } from 'react';
import './App.css';
import BaseRouter from './routes'
import {BrowserRouter as Router} from 'react-router-dom'
import OuterLayout from './Containers/_layout'
class App extends Component {
  render() {
    return (
      <div className="App">
        <Router>
          <OuterLayout>
              
                  <BaseRouter />
              
          </OuterLayout>
        </Router>
      </div>
    );
  }
}

export default App;
