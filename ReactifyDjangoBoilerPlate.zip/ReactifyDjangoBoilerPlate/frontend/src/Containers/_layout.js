import React, { Component } from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';

// const { Header, Content, Footer } = Layout;



class OuterLayout extends Component {
    state = {  }
    render() { 
        return ( 
        <Layout>
            
                <div style={{ background: '#fff', padding: 40, minHeight: 380 }}>
                    {this.props.children}
                </div>
            
     </Layout> );
    }
}
 
export default OuterLayout;
