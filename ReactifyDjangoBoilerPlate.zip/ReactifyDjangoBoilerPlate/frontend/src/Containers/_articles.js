import React, { Component } from 'react';
import axios from 'axios';
import { List, Avatar, Icon } from 'antd';
const IconText = ({ type, text }) => (
    <span>
      <Icon type={type} style={{ marginRight: 8 }} />
      {text}
    </span>
  );
class ArticlesLayout extends Component {
    state = {
        articles:[],
      }
    componentDidMount() {
        
        axios.get('http://127.0.0.1:8000/chuangze.cn/api/articles/')
        .then(res=>{this.setState({ articles:res.data  });
        console.log(this.state.articles)
        })
       
      }
    
    render() { 
        return ( 
        <React.Fragment>
        <b><h1>All Articles</h1></b>
        <hr/>
            <List
    itemLayout="vertical"
    size="large"
    pagination={{
      onChange: (page) => {
        console.log(page);
      },
      pageSize: 3,
    }}
    dataSource={this.state.articles}
    // footer={<div><b>ant design</b> footer part</div>}
    renderItem={item => (
      <List.Item
        key={item.title}
        actions={[<IconText type="star-o" text="156" />, <IconText type="like-o" text="156" />, <IconText type="message" text="2" />]}
        extra={<img width={272} alt="logo" src={item.ArticleImages1} />}
      >
        <List.Item.Meta
          avatar={<Avatar src={item.ArticleImages} />}
          title={<h5><a href={`${item.id}/`}>{item.ArticleTitle}</a></h5>}
          description={item.ArticleDescription}
        />
        {item.content}
      </List.Item>
    )}
  />
  </React.Fragment>
         );
    }
}
 
export default ArticlesLayout;


