import React, { Component } from 'react';
import { Card, List } from 'antd';
import axios from 'axios';
const { Meta } = Card;

// const IconText = ({ type, text }) => (
//   <span>
//     <Icon type={type} style={{ marginRight: 8 }} />
//     {text}
//   </span>
// );
class MainProducts extends Component {
  state = { 
    allProducts:[],
  }
  componentDidMount() {
    axios.get('http://127.0.0.1:8000/chuangze.cn/api/')
    .then(res=>{
      this.setState({ allProducts:res.data  });
      console.log(res.data)
    })
    .catch(Error=>{console.log(Error)})
    console.log("cate",this.state.allProducts.ProductCategory)
    
  }
  render() { 
    return (  <React.Fragment>
      <div className="search-result-list">
      <b><h1>All Products</h1></b>
      <hr/>
            <List
            grid={{ gutter: 16, xs: 1, sm: 2, md: 2, lg: 3, xl: 4, xxl: 4 }}
            dataSource={this.state.allProducts}
            
            renderItem={item => (
              <List.Item>
                <a href={`${item.id}/`}>
                <Card            
                  hoverable="true"
                  style={{ width: 240 }}
                  cover={<img alt="example" src={item.ProductImages} />}
                >
                <Meta
                  title={item.ProductTitle}
                  description={item.ProductCategory}
                />
              </Card></a>
              </List.Item>
        
      )}
    />
    </div></React.Fragment>
     );
  }

}
 
export default MainProducts;