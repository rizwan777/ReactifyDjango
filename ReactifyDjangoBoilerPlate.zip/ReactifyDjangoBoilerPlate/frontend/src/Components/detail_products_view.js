import React, { Component } from 'react';
import axios from 'axios';
import { Card } from 'antd';
import { Icon } from 'antd';
const { Meta } = Card;

class DetailProductView extends Component {
    state = {  
        article:{},
        DetailArticle:[],
        did:null,
    }
    componentDidMount() {
        const id = this.props.match.params.id
       
        const detail_id = id 
        console.log("Ddd",detail_id)
        
        console.log("value of id is",id)
        axios.get(`http://127.0.0.1:8000/chuangze.cn/${id}/api/`)
        .then(res=>{this.setState({ article:res.data  });
        
        })
        .catch(Error=>{console.log(Error)})
        
        axios.get(`http://127.0.0.1:8000/chuangze.cn/${detail_id}/api/details/`)
        .then(res=>{
            this.setState({ DetailArticle:res.data  });
            console.log(res.data)
        })
        .catch(Error=>{console.log(Error)})
        // const articletype= {this.state.article.articletype}
        
    }
    render() { 
        
            return ( 
                
            <div className="search-result-list">
            <b><h1>Detail Product</h1></b>   
                    
                
            <div>
                    
                    <hr className="featurette-divider" />
                    <div className="row featurette">
                        <div className="col-md-4">
                        <Card
                        hoverable
                        style={{ width: 240 }}
                        cover={<img alt="example" src={this.state.article.ProductImages} />}
                        >
                        <Meta
                        title={this.state.article.ProductTitle}
                        description={this.state.article.ProductCategory}
                        />
                        </Card><br/>
                                <h2 className="featurette-heading"> {this.state.DetailArticle.ArticleTitle} <span className="text-muted">It'll blow your mind.</span></h2>
                                <b><h4><Icon type="compass" /> {this.state.DetailArticle.ArticleLocation}, <Icon type="clock-circle" /> {this.state.DetailArticle.ArticleUpdateTime}</h4></b>
                                <p className="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
                                
                        </div>
                        <div className="col-md-8">
                        <img className="featurette-image img-fluid mx-auto" src={this.state.DetailArticle.ArticleImages1} alt="details Article " />
                        <img className="featurette-image img-fluid mx-auto" src={this.state.DetailArticle.ArticleImages2}  />
                        <img className="featurette-image img-fluid mx-auto" src={this.state.DetailArticle.ArticleImages3}  />
                        </div>
                    

                        <hr className="featurette-divider"/>
                    </div>                     
            </div>
            </div>
                 );
    }
}
 

export default DetailProductView;