from django.shortcuts import render, get_object_or_404
from .models import  Products
from rest_framework import generics
from .serializers import ProductSerializers,ArticleSerializer,DetailArticlesSerialzer
from .models import Products,ArticleDetails,DetailsArticles
from django.db.models import Q

from django.http import Http404

# # Create your views here.
def index_view(request):
    if request.method =="POST":
        data1 = request.POST.get('search')
        print('search=>', data1)
    data = Products.objects.all()
    print("all data", data)
    context={
        'data':data,

    }
    print(context)
    return render(request,'index.html',context)

def search_view(request):
    if request.method == 'POST':
        entered_Data =request.POST.get('search')
        data = Products.objects.filter(Q(ProductTitle__icontains=entered_Data) | Q(ProductCategory__icontains=entered_Data))
        print(data)

        search_Data = {
            'TargetFields':data,
        }
    return render(request,'index.html',search_Data)

def Details_view(request,id):
    # obj = get_object_or_404(Products,pk=pk)
    obj = ArticleDetails.objects.all().filter(id=id)
    print("details =>",obj)
    context={
            'data': obj,
        }
    return render(request,'details.html',context)






## this below methods are helpful for API integration with urls

class AllProductsSerializer(generics.ListAPIView):
    serializer_class = ProductSerializers
    queryset = Products.objects.all()
class serviceProductsSerializer(generics.ListAPIView):
    lookup_field = "ServiceRobot"
    serializer_class = ProductSerializers

    def get_queryset(self):
        return Products.objects.filter(self,Products.ProductCategory.primary_key)

class SingleProductSerializer(generics.RetrieveAPIView):
    lookup_field = "id"
    serializer_class = ProductSerializers
    queryset = Products.objects.all()

class AllDetailProductSerializer(generics.ListAPIView):
    serializer_class = ArticleSerializer
    queryset = ArticleDetails.objects.all()

class ArticleSingleSerializer(generics.RetrieveAPIView):
    lookup_field = "id"
    serializer_class = ArticleSerializer
    queryset = ArticleDetails.objects.all()

class ArticleCreateSerializer(generics.CreateAPIView):
    serializer_class = ArticleSerializer
    queryset = ArticleDetails.objects.all()


class AllArticlesSerializer(generics.ListAPIView):
    serializer_class = DetailArticlesSerialzer
    queryset = DetailsArticles.objects.all()

class SigleArticlesSerializer(generics.RetrieveAPIView):
    lookup_field = "id"
    serializer_class = DetailArticlesSerialzer
    queryset = DetailsArticles.objects.all()