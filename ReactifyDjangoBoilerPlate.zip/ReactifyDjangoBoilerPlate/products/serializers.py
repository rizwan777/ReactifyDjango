from rest_framework import serializers
from .models import Products, ArticleDetails,DetailsArticles

class ProductSerializers(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = "__all__"
        ordering =['pk']

class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = ArticleDetails
        fields ="__all__"
        ordering =['pk']

class DetailArticlesSerialzer(serializers.ModelSerializer):
    class Meta:
        model = DetailsArticles
        fields = "__all__"
        ordering =['pk']