"""ReactifyDjangoBoilerPlate URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from products import views

app_name="chuangze.cn"
urlpatterns = [
    url(r'^$', views.index_view),
    url(r'^search/$', views.search_view),
    url(r'^(?P<id>[0-9])/$', views.Details_view),
    ##below urls are responsible to heandling of API's URL's##
    url(r'^api/$', views.AllProductsSerializer.as_view()),
    url(r'^ServiceRobot/api/$', views.serviceProductsSerializer.as_view()),
    url(r'^(?P<id>[0-9])/api/$', views.SingleProductSerializer.as_view()),
    url(r'^api/details/$', views.AllDetailProductSerializer.as_view()),
    url(r'^(?P<id>[0-9])/api/details/$', views.ArticleSingleSerializer.as_view()),
    url(r'^api/create/$',views.ArticleCreateSerializer.as_view()),
    url(r'^api/articles/$',views.AllArticlesSerializer.as_view()),
    url(r'^api/(?P<id>[0-9])/articles/$',views.SigleArticlesSerializer.as_view()),

]