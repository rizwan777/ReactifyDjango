from django.db import models
from django.utils import timezone
# Create your models here.
class Products(models.Model):

    ProductTitle            =       models.CharField(max_length=100)
    ProductCategory            =       models.CharField(max_length=100)
    ProductImages            =       models.ImageField(upload_to='images/',)

    def __str__(self):
        return self.ProductCategory
    class Meta:
        ordering =["pk"]

class ArticleDetails(models.Model):
    # ProductCategory               = models.ForeignKey(Products,on_delete=models.CASCADE)
    ProductCategory         = models.ManyToOneRel(to=Products.ProductCategory,field_name=Products.ProductCategory,field=Products.ProductCategory,on_delete=models.CASCADE)
    ArticleTitle            = models.CharField(max_length=100)
    ArticleDescription      = models.CharField(max_length=3000)
    ArticleImages           = models.ImageField(upload_to='images/',blank=True)
    ArticleImages1          = models.ImageField(upload_to='images/',blank=True)
    ArticleImages2          = models.ImageField(upload_to='images/',blank=True)
    ArticleImages3          = models.ImageField(upload_to='images/',blank=True)
    ArticleLocation         = models.CharField(max_length=100)
    ArticleUpdateTime       = models.DateField(auto_now_add=timezone.now)


    def __str__(self):
        return self.ArticleTitle

    class Meta:
        ordering = ["pk"]

class DetailsArticles(models.Model):
    ArticleTitle = models.CharField(max_length=100)
    ArticleImages = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription = models.CharField(max_length=3000)
    ArticleImages1 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription1 = models.CharField(max_length=3000, blank=True)
    ArticleImages2 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription2 = models.CharField(max_length=3000, blank=True)
    ArticleImages3 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription3 = models.CharField(max_length=3000, blank=True)
    ArticleImages4 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription4 = models.CharField(max_length=3000, blank=True)
    ArticleImages5 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription5 = models.CharField(max_length=3000, blank=True)
    ArticleImages6 = models.ImageField(upload_to='images/articles/', blank=True)
    ArticleDescription6 = models.CharField(max_length=3000, blank=True)
    ArticleLocation= models.CharField(max_length=100, blank=True)
    ArticleUpdatedTime = models.DateTimeField(auto_now_add=timezone)

    def __str__(self):
        return self.ArticleTitle