#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ReactifyDjangoBoilerPlate.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
    # this below code is used full for run two command for react and django together.from
    # by  using command :::  python manage.py runsever react
    #
    # try:
    #     if sys.argv[2] == 'react':
    #         project_root = os.getcwd()
    #         os.chdir(os.path.join(project_root,"frontend"))
    #         os.system("npm run build")
    #         os.chdir(project_root)
    #         sys.argv.pop(2)
    # except:
    #     execute_from_command_line(sys.argv)
    # else:
    #     execute_from_command_line(sys.argv)

#!/usr/bin/env python
import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ReactifyDjangoBoilerPlate.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


    # this below code is used full for run two command for react and django together.from
    # by  using command :::  python manage.py runsever react
    #
    # try:
    #     if sys.argv[2] == 'react':
    #         project_root = os.getcwd()
    #         os.chdir(os.path.join(project_root,"frontend"))
    #         os.system("npm run build")
    #         os.chdir(project_root)
    #         sys.argv.pop(2)
    # except:
    #     execute_from_command_line(sys.argv)
    # else:
    #     execute_from_command_line(sys.argv)
    # project_root = os.getcwd()
    # print(project_root)
    # os.chdir(os.path.join(project_root, "frontend"))
    # os.system("npm run build")
    # os.chdir(project_root)
    # sys.argv.pop(3)
    # execute_from_command_line(sys.argv)

